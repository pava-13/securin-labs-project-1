from flask import Flask, request, jsonify, render_template
from flask_bcrypt import Bcrypt
from flask_jwt_extended import (
    JWTManager,
    create_access_token,
    jwt_required,
    get_jwt_identity
)
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import sqlite3
import datetime
import uuid

app = Flask(__name__)

app.config["JWT_SECRET_KEY"] = "super-secret-key"
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = datetime.timedelta(minutes=30)

bcrypt = Bcrypt(app)
jwt = JWTManager(app)

# Basic rate limiting to prevent brute-force attacks
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["100 per hour"]
)

def init_db():
    conn = sqlite3.connect("models.db")
    cursor = conn.cursor()

    # Users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    """)

    # Transactions table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            id TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            currency TEXT NOT NULL,
            merchant_id TEXT NOT NULL,
            timestamp TEXT NOT NULL
        )
    """)

    conn.commit()
    conn.close()

init_db()

@app.route("/register", methods=["POST"])
def register():

    data = request.get_json()
    email = data.get("email")
    password = data.get("password")

    if not email or not password:
        return jsonify({"error": "Email and password are required"}), 400

    hashed_password = bcrypt.generate_password_hash(password).decode("utf-8")

    try:
        conn = sqlite3.connect("models.db")
        cursor = conn.cursor()

        cursor.execute(
            "INSERT INTO users (email, password) VALUES (?, ?)",
            (email, hashed_password)
        )

        conn.commit()
        conn.close()

        return jsonify({"message": "User registered successfully"}), 201

    except sqlite3.IntegrityError:
        return jsonify({"error": "Email already exists"}), 400

@app.route("/login", methods=["POST"])
@limiter.limit("5 per minute")
def login():

    data = request.get_json()
    email = data.get("email")
    password = data.get("password")

    conn = sqlite3.connect("models.db")
    cursor = conn.cursor()

    cursor.execute(
        "SELECT id, password FROM users WHERE email = ?",
        (email,)
    )

    user = cursor.fetchone()
    conn.close()

    if user and bcrypt.check_password_hash(user[1], password):

        # JWT identity must be string
        access_token = create_access_token(identity=str(user[0]))

        return jsonify({"access_token": access_token}), 200

    return jsonify({"error": "Invalid credentials"}), 401
@app.route("/payment", methods=["POST"])
@jwt_required()
def make_payment():

    user_id = int(get_jwt_identity())
    data = request.get_json()

    amount = data.get("amount")
    currency = data.get("currency")
    merchant_id = data.get("merchant_id")

    if not amount or float(amount) <= 0:
        return jsonify({"error": "Invalid amount"}), 400

    transaction_id = str(uuid.uuid4())

    conn = sqlite3.connect("models.db")
    cursor = conn.cursor()

    # Basic duplicate payment prevention
    cursor.execute("""
        SELECT * FROM transactions
        WHERE user_id = ? AND amount = ? AND merchant_id = ?
    """, (user_id, amount, merchant_id))

    if cursor.fetchone():
        conn.close()
        return jsonify({"error": "Duplicate payment detected"}), 400

    cursor.execute("""
        INSERT INTO transactions VALUES (?, ?, ?, ?, ?, ?)
    """, (
        transaction_id,
        user_id,
        amount,
        currency,
        merchant_id,
        datetime.datetime.utcnow().isoformat()
    ))

    conn.commit()
    conn.close()

    return jsonify({
        "message": "Payment successful",
        "transaction_id": transaction_id
    })

@app.route("/transactions", methods=["GET"])
@jwt_required()
def get_transactions():

    user_id = int(get_jwt_identity())

    conn = sqlite3.connect("models.db")
    cursor = conn.cursor()

    cursor.execute("""
        SELECT amount, currency, merchant_id, timestamp
        FROM transactions
        WHERE user_id = ?
    """, (user_id,))

    transactions = cursor.fetchall()
    conn.close()

    return jsonify({"transactions": transactions})

@app.route("/")
def home():
    return render_template("login.html")


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


@app.route("/register-page")
def register_page():
    return render_template("register.html")
if __name__ == "__main__":
    app.run(debug=True)
